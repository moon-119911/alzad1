import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { FileCard } from "@/components/files/file-card"
import { Bookmark } from "lucide-react"
import type { StudyFile } from "@/lib/types"

export default async function SavedFilesPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  const supabase = await createClient()

  const { data: savedFiles } = await supabase
    .from("saved_files")
    .select(`
      *,
      file:study_files(
        *,
        content_type:content_types(*),
        subject:subjects(*),
        academic_year:academic_years(*),
        uploader:profiles(id, full_name, avatar_url)
      )
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  const files = savedFiles
    ?.map(sf => sf.file)
    .filter(Boolean) as StudyFile[] || []

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Bookmark className="h-8 w-8 text-primary" />
              المحفوظات
            </h1>
            <p className="text-muted-foreground mt-2">
              الملفات التي قمت بحفظها للرجوع إليها لاحقاً
            </p>
          </div>

          {files.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {files.map((file) => (
                <FileCard key={file.id} file={file} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="p-4 rounded-full bg-muted mb-4">
                <Bookmark className="h-10 w-10 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">لا توجد ملفات محفوظة</h3>
              <p className="text-muted-foreground max-w-md">
                عند حفظ ملف، سيظهر هنا للرجوع إليه بسهولة لاحقاً
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
