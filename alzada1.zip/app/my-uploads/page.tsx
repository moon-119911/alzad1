import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { FileCard } from "@/components/files/file-card"
import { Button } from "@/components/ui/button"
import { Upload, FileText } from "lucide-react"
import type { StudyFile } from "@/lib/types"

export default async function MyUploadsPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  const supabase = await createClient()

  const { data: files } = await supabase
    .from("study_files")
    .select(`
      *,
      content_type:content_types(*),
      subject:subjects(*),
      academic_year:academic_years(*),
      uploader:profiles(id, full_name, avatar_url)
    `)
    .eq("uploader_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <Upload className="h-8 w-8 text-primary" />
                ملفاتي
              </h1>
              <p className="text-muted-foreground mt-2">
                الملفات التي قمت برفعها ({files?.length || 0} ملف)
              </p>
            </div>
            <Link href="/upload">
              <Button className="gap-2">
                <Upload className="h-4 w-4" />
                رفع ملف جديد
              </Button>
            </Link>
          </div>

          {files && files.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {files.map((file) => (
                <FileCard key={file.id} file={file as StudyFile} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="p-4 rounded-full bg-muted mb-4">
                <FileText className="h-10 w-10 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">لم ترفع أي ملفات بعد</h3>
              <p className="text-muted-foreground max-w-md mb-4">
                شارك ملفاتك الدراسية مع زملائك وساهم في إثراء المحتوى
              </p>
              <Link href="/upload">
                <Button className="gap-2">
                  <Upload className="h-4 w-4" />
                  رفع ملف الآن
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
