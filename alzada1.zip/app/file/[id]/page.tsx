import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { notFound } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { FileDetails } from "./file-details"
import { FileActions } from "./file-actions"
import { FileComments } from "./file-comments"
import type { StudyFile, Comment, FileRating } from "@/lib/types"

interface FilePageProps {
  params: Promise<{ id: string }>
}

export default async function FilePage({ params }: FilePageProps) {
  const { id } = await params
  const user = await getCurrentUser()
  const supabase = await createClient()

  // جلب تفاصيل الملف
  const { data: file, error } = await supabase
    .from("study_files")
    .select(`
      *,
      content_type:content_types(*),
      subject:subjects(*, level:levels(*), major:majors(*, university:universities(*))),
      academic_year:academic_years(*),
      uploader:profiles(id, full_name, avatar_url, university_id, major_id)
    `)
    .eq("id", id)
    .single()

  if (error || !file) {
    notFound()
  }

  // التحقق من صلاحية العرض (نفس الجامعة والتخصص)
  if (user && file.subject?.major) {
    const userMajor = user.major_id
    const fileMajor = file.subject.major_id
    
    // إذا كان المستخدم من تخصص مختلف، لا يمكنه رؤية الملف
    if (userMajor !== fileMajor && !user.is_admin) {
      notFound()
    }
  }

  // زيادة عداد المشاهدات
  await supabase
    .from("study_files")
    .update({ views_count: (file.views_count || 0) + 1 })
    .eq("id", id)

  // جلب التقييمات
  const { data: ratings } = await supabase
    .from("file_ratings")
    .select("rating")
    .eq("file_id", id)

  const averageRating = ratings && ratings.length > 0
    ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
    : 0

  // جلب تقييم المستخدم الحالي
  let userRating: number | null = null
  if (user) {
    const { data: userRatingData } = await supabase
      .from("file_ratings")
      .select("rating")
      .eq("file_id", id)
      .eq("user_id", user.id)
      .single()
    
    userRating = userRatingData?.rating || null
  }

  // جلب حالة الحفظ
  let isSaved = false
  if (user) {
    const { data: savedData } = await supabase
      .from("saved_files")
      .select("id")
      .eq("file_id", id)
      .eq("user_id", user.id)
      .single()
    
    isSaved = !!savedData
  }

  // جلب التعليقات
  const { data: comments } = await supabase
    .from("comments")
    .select(`
      *,
      user:profiles(id, full_name, avatar_url)
    `)
    .eq("file_id", id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            <div className="space-y-8">
              <FileDetails 
                file={file as StudyFile} 
                averageRating={averageRating}
                ratingsCount={ratings?.length || 0}
              />
              
              <FileComments 
                fileId={id}
                comments={(comments || []) as Comment[]}
                user={user}
              />
            </div>

            <aside>
              <FileActions
                file={file as StudyFile}
                user={user}
                userRating={userRating}
                isSaved={isSaved}
              />
            </aside>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
