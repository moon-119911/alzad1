import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { ProfileView } from "./profile-view"
import type { UserStats } from "@/lib/types"

export default async function ProfilePage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  const supabase = await createClient()

  // جلب إحصائيات المستخدم
  const { data: userFiles } = await supabase
    .from("study_files")
    .select("views_count, downloads_count")
    .eq("uploader_id", user.id)

  // حساب متوسط التقييم
  const { data: ratings } = await supabase
    .from("file_ratings")
    .select("rating, file:study_files!inner(uploader_id)")
    .eq("file.uploader_id", user.id)

  const stats: UserStats = {
    uploadedFiles: userFiles?.length || 0,
    totalDownloads: userFiles?.reduce((sum, f) => sum + (f.downloads_count || 0), 0) || 0,
    totalViews: userFiles?.reduce((sum, f) => sum + (f.views_count || 0), 0) || 0,
    averageRating: ratings && ratings.length > 0
      ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
      : 0,
  }

  // جلب معلومات الجامعة والتخصص والمستوى
  const { data: fullProfile } = await supabase
    .from("profiles")
    .select(`
      *,
      university:universities(*),
      major:majors(*),
      level:levels(*)
    `)
    .eq("id", user.id)
    .single()

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container max-w-4xl">
          <ProfileView 
            user={fullProfile || user} 
            stats={stats} 
          />
        </div>
      </main>

      <Footer />
    </div>
  )
}
