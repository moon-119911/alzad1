import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { SearchFilters } from "./search-filters"
import { SearchResults } from "./search-results"
import type { ContentType, Level, AcademicYear, Subject } from "@/lib/types"

interface SearchPageProps {
  searchParams: Promise<{
    q?: string
    type?: string
    level?: string
    year?: string
    subject?: string
    sort?: string
    page?: string
  }>
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const params = await searchParams
  const user = await getCurrentUser()
  const supabase = await createClient()

  // جلب بيانات الفلاتر
  const [contentTypes, levels, academicYears] = await Promise.all([
    supabase.from("content_types").select("*").order("name"),
    supabase.from("levels").select("*").order("order_num"),
    supabase.from("academic_years").select("*").order("name", { ascending: false }),
  ])

  // جلب المواد المتاحة للمستخدم
  let subjects: Subject[] = []
  if (user?.major_id) {
    const { data } = await supabase
      .from("subjects")
      .select("*")
      .eq("major_id", user.major_id)
      .order("name")
    subjects = data || []
  }

  // بناء استعلام البحث
  const page = parseInt(params.page || "1")
  const limit = 12
  const offset = (page - 1) * limit

  let query = supabase
    .from("study_files")
    .select(`
      *,
      content_type:content_types(*),
      subject:subjects(*),
      academic_year:academic_years(*),
      uploader:profiles(id, full_name, avatar_url)
    `, { count: "exact" })
    .eq("is_approved", true)

  // تصفية حسب تخصص المستخدم
  if (user?.major_id) {
    const { data: userSubjects } = await supabase
      .from("subjects")
      .select("id")
      .eq("major_id", user.major_id)
    
    if (userSubjects && userSubjects.length > 0) {
      query = query.in("subject_id", userSubjects.map(s => s.id))
    }
  }

  // البحث بالنص
  if (params.q) {
    query = query.or(`title.ilike.%${params.q}%,description.ilike.%${params.q}%`)
  }

  // تصفية حسب نوع المحتوى
  if (params.type) {
    query = query.eq("content_type_id", params.type)
  }

  // تصفية حسب المستوى
  if (params.level && subjects.length > 0) {
    const levelSubjects = subjects.filter(s => s.level_id === params.level)
    if (levelSubjects.length > 0) {
      query = query.in("subject_id", levelSubjects.map(s => s.id))
    }
  }

  // تصفية حسب العام الدراسي
  if (params.year) {
    query = query.eq("academic_year_id", params.year)
  }

  // تصفية حسب المادة
  if (params.subject) {
    query = query.eq("subject_id", params.subject)
  }

  // الترتيب
  switch (params.sort) {
    case "most_downloaded":
      query = query.order("downloads_count", { ascending: false })
      break
    case "most_viewed":
      query = query.order("views_count", { ascending: false })
      break
    default:
      query = query.order("created_at", { ascending: false })
  }

  // التصفح
  query = query.range(offset, offset + limit - 1)

  const { data: files, count } = await query

  const totalPages = Math.ceil((count || 0) / limit)

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">البحث عن ملفات</h1>
            <p className="text-muted-foreground mt-2">
              {user 
                ? "ابحث في ملفات تخصصك وجامعتك"
                : "سجل دخولك لعرض الملفات المخصصة لتخصصك"}
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
            <aside>
              <SearchFilters
                contentTypes={(contentTypes.data || []) as ContentType[]}
                levels={(levels.data || []) as Level[]}
                academicYears={(academicYears.data || []) as AcademicYear[]}
                subjects={subjects}
                currentFilters={params}
              />
            </aside>

            <div>
              <SearchResults
                files={files || []}
                totalCount={count || 0}
                currentPage={page}
                totalPages={totalPages}
                searchQuery={params.q}
              />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
