import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  Building2, 
  Flag,
  Download,
  Eye,
  TrendingUp
} from "lucide-react"
import Link from "next/link"

export default async function AdminPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  if (!user.is_admin) {
    redirect("/")
  }

  const supabase = await createClient()

  // جلب الإحصائيات
  const [
    filesCount,
    usersCount,
    universitiesCount,
    pendingReports,
    totalDownloads,
    totalViews
  ] = await Promise.all([
    supabase.from("study_files").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("*", { count: "exact", head: true }).eq("is_profile_complete", true),
    supabase.from("universities").select("*", { count: "exact", head: true }),
    supabase.from("file_reports").select("*", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("study_files").select("downloads_count"),
    supabase.from("study_files").select("views_count"),
  ])

  const stats = [
    { 
      label: "إجمالي الملفات", 
      value: filesCount.count || 0, 
      icon: FileText,
      color: "text-blue-600 bg-blue-100 dark:bg-blue-900/30",
      href: "/admin/files"
    },
    { 
      label: "المستخدمون", 
      value: usersCount.count || 0, 
      icon: Users,
      color: "text-green-600 bg-green-100 dark:bg-green-900/30",
      href: "/admin/users"
    },
    { 
      label: "الجامعات", 
      value: universitiesCount.count || 0, 
      icon: Building2,
      color: "text-purple-600 bg-purple-100 dark:bg-purple-900/30",
      href: "/admin/universities"
    },
    { 
      label: "بلاغات معلقة", 
      value: pendingReports.count || 0, 
      icon: Flag,
      color: "text-red-600 bg-red-100 dark:bg-red-900/30",
      href: "/admin/reports"
    },
    { 
      label: "إجمالي التحميلات", 
      value: totalDownloads.data?.reduce((sum, f) => sum + (f.downloads_count || 0), 0) || 0, 
      icon: Download,
      color: "text-amber-600 bg-amber-100 dark:bg-amber-900/30",
    },
    { 
      label: "إجمالي المشاهدات", 
      value: totalViews.data?.reduce((sum, f) => sum + (f.views_count || 0), 0) || 0, 
      icon: Eye,
      color: "text-cyan-600 bg-cyan-100 dark:bg-cyan-900/30",
    },
  ]

  // جلب أحدث الملفات
  const { data: recentFiles } = await supabase
    .from("study_files")
    .select(`
      id, title, created_at,
      uploader:profiles(full_name)
    `)
    .order("created_at", { ascending: false })
    .limit(5)

  // جلب أحدث البلاغات
  const { data: recentReports } = await supabase
    .from("file_reports")
    .select(`
      id, reason, status, created_at,
      reporter:profiles!file_reports_reporter_id_fkey(full_name),
      file:study_files(title)
    `)
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <LayoutDashboard className="h-8 w-8 text-primary" />
              لوحة التحكم
            </h1>
            <p className="text-muted-foreground mt-2">
              مرحباً {user.full_name}، إليك نظرة عامة على المنصة
            </p>
          </div>

          {/* الإحصائيات */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 mb-8">
            {stats.map((stat) => {
              const Icon = stat.icon
              const content = (
                <Card className={stat.href ? "hover:shadow-md transition-shadow cursor-pointer" : ""}>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-xl ${stat.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{stat.value.toLocaleString("ar")}</p>
                        <p className="text-sm text-muted-foreground">{stat.label}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )

              return stat.href ? (
                <Link key={stat.label} href={stat.href}>
                  {content}
                </Link>
              ) : (
                <div key={stat.label}>{content}</div>
              )
            })}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* أحدث الملفات */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">أحدث الملفات</CardTitle>
                <Link href="/admin/files" className="text-sm text-primary hover:underline">
                  عرض الكل
                </Link>
              </CardHeader>
              <CardContent>
                {recentFiles && recentFiles.length > 0 ? (
                  <div className="space-y-4">
                    {recentFiles.map((file) => (
                      <div key={file.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium line-clamp-1">{file.title}</p>
                          <p className="text-sm text-muted-foreground">
                            بواسطة {file.uploader?.full_name || "مستخدم"}
                          </p>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(file.created_at).toLocaleDateString("ar")}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">لا توجد ملفات</p>
                )}
              </CardContent>
            </Card>

            {/* أحدث البلاغات */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">أحدث البلاغات</CardTitle>
                <Link href="/admin/reports" className="text-sm text-primary hover:underline">
                  عرض الكل
                </Link>
              </CardHeader>
              <CardContent>
                {recentReports && recentReports.length > 0 ? (
                  <div className="space-y-4">
                    {recentReports.map((report) => (
                      <div key={report.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium line-clamp-1">{report.file?.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {report.reason} - بواسطة {report.reporter?.full_name}
                          </p>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          report.status === "pending" 
                            ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                            : "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        }`}>
                          {report.status === "pending" ? "معلق" : "تمت المراجعة"}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">لا توجد بلاغات</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
