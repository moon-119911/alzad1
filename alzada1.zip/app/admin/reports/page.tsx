import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { ReportsList } from "./reports-list"
import { Flag } from "lucide-react"

export default async function ReportsPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  if (!user.is_admin) {
    redirect("/")
  }

  const supabase = await createClient()

  const { data: reports } = await supabase
    .from("file_reports")
    .select(`
      *,
      reporter:profiles!file_reports_reporter_id_fkey(id, full_name, email),
      file:study_files(id, title, uploader:profiles(full_name))
    `)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />

      <main className="flex-1 py-8">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Flag className="h-8 w-8 text-primary" />
              إدارة البلاغات
            </h1>
            <p className="text-muted-foreground mt-2">
              مراجعة البلاغات المقدمة من المستخدمين
            </p>
          </div>

          <ReportsList reports={reports || []} />
        </div>
      </main>

      <Footer />
    </div>
  )
}
