import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { CompleteProfileForm } from "./complete-profile-form"

export default async function CompleteProfilePage() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }

  // التحقق من اكتمال الملف الشخصي
  const { data: profile } = await supabase
    .from("profiles")
    .select("is_profile_complete")
    .eq("id", user.id)
    .single()

  if (profile?.is_profile_complete) {
    redirect("/")
  }

  // جلب البيانات اللازمة
  const [universities, levels] = await Promise.all([
    supabase.from("universities").select("*").order("name"),
    supabase.from("levels").select("*").order("order_num"),
  ])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-background to-muted/30 p-4">
      <CompleteProfileForm
        userId={user.id}
        userEmail={user.email || ""}
        userName={user.user_metadata?.full_name || user.user_metadata?.name || ""}
        userAvatar={user.user_metadata?.avatar_url || user.user_metadata?.picture || ""}
        universities={universities.data || []}
        levels={levels.data || []}
      />
    </div>
  )
}
