import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"
import { createClient } from "@/lib/supabase/server"
import { ALLOWED_FILE_TYPES, MAX_FILE_SIZE } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // التحقق من المصادقة
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // التحقق من اكتمال الملف الشخصي
    const { data: profile } = await supabase
      .from("profiles")
      .select("*, major:majors(*), level:levels(*)")
      .eq("id", user.id)
      .single()

    if (!profile?.is_profile_complete) {
      return NextResponse.json({ error: "يجب إكمال الملف الشخصي أولاً" }, { status: 403 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const subjectId = formData.get("subjectId") as string
    const contentTypeId = formData.get("contentTypeId") as string
    const academicYearId = formData.get("academicYearId") as string

    // التحقق من البيانات
    if (!file || !title || !subjectId || !contentTypeId || !academicYearId) {
      return NextResponse.json({ error: "جميع الحقول مطلوبة" }, { status: 400 })
    }

    // التحقق من نوع الملف
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      return NextResponse.json({ 
        error: "نوع الملف غير مسموح. الأنواع المسموحة: PDF, Word, PowerPoint, الصور" 
      }, { status: 400 })
    }

    // التحقق من حجم الملف
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ 
        error: "حجم الملف يتجاوز الحد الأقصى (50 ميجابايت)" 
      }, { status: 400 })
    }

    // التحقق من أن المادة تنتمي لتخصص المستخدم
    const { data: subject } = await supabase
      .from("subjects")
      .select("*, level:levels(*)")
      .eq("id", subjectId)
      .single()

    if (!subject) {
      return NextResponse.json({ error: "المادة غير موجودة" }, { status: 400 })
    }

    if (subject.major_id !== profile.major_id) {
      return NextResponse.json({ 
        error: "لا يمكنك رفع ملفات لمواد خارج تخصصك" 
      }, { status: 403 })
    }

    // التحقق من أن المادة في مستوى المستخدم أو أقل
    if (subject.level && profile.level) {
      if (subject.level.order_num > profile.level.order_num) {
        return NextResponse.json({ 
          error: "لا يمكنك رفع ملفات لمستوى أعلى من مستواك الحالي" 
        }, { status: 403 })
      }
    }

    // رفع الملف إلى Vercel Blob
    const timestamp = Date.now()
    const safeName = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const pathname = `files/${user.id}/${timestamp}-${safeName}`

    const blob = await put(pathname, file, {
      access: "private",
    })

    // إضافة سجل الملف في قاعدة البيانات
    const { data: studyFile, error: dbError } = await supabase
      .from("study_files")
      .insert({
        title: title.trim(),
        description: description?.trim() || null,
        file_url: blob.url,
        file_pathname: blob.pathname,
        file_size: file.size,
        file_type: file.type,
        content_type_id: contentTypeId,
        subject_id: subjectId,
        academic_year_id: academicYearId,
        uploader_id: user.id,
        is_approved: true, // يمكن تغييرها إلى false إذا كنت تريد المراجعة
      })
      .select()
      .single()

    if (dbError) {
      console.error("Database error:", dbError)
      return NextResponse.json({ error: "فشل حفظ الملف" }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      file: studyFile 
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "فشل رفع الملف" }, { status: 500 })
  }
}
