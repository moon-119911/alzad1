import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          )
          supabaseResponse = NextResponse.next({
            request,
          })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options),
          )
        },
      },
    },
  )

  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Public routes that don't require authentication
  const publicRoutes = ['/', '/auth/login', '/auth/callback', '/auth/error']
  const isPublicRoute = publicRoutes.some(route => 
    request.nextUrl.pathname === route || request.nextUrl.pathname.startsWith('/auth/')
  )

  // If not logged in and trying to access protected route
  if (!user && !isPublicRoute) {
    const url = request.nextUrl.clone()
    url.pathname = '/auth/login'
    return NextResponse.redirect(url)
  }

  // If logged in, check if profile is complete
  if (user && !isPublicRoute && !request.nextUrl.pathname.startsWith('/complete-profile')) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('university_id, major_id, level_id')
      .eq('id', user.id)
      .single()

    // Redirect to complete profile if missing required fields
    if (!profile?.university_id || !profile?.major_id || !profile?.level_id) {
      const url = request.nextUrl.clone()
      url.pathname = '/complete-profile'
      return NextResponse.redirect(url)
    }
  }

  // If on complete-profile page but profile is already complete, redirect to home
  if (user && request.nextUrl.pathname === '/complete-profile') {
    const { data: profile } = await supabase
      .from('profiles')
      .select('university_id, major_id, level_id')
      .eq('id', user.id)
      .single()

    if (profile?.university_id && profile?.major_id && profile?.level_id) {
      const url = request.nextUrl.clone()
      url.pathname = '/'
      return NextResponse.redirect(url)
    }
  }

  return supabaseResponse
}
