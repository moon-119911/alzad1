-- =====================================================
-- منصة الزاد - إنشاء جداول قاعدة البيانات
-- =====================================================

-- 1. جدول الجامعات
CREATE TABLE IF NOT EXISTS universities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  logo_url TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. جدول التخصصات
CREATE TABLE IF NOT EXISTS majors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  university_id UUID NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(university_id, name)
);

-- 3. جدول المستويات الدراسية
CREATE TABLE IF NOT EXISTS levels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  order_num INT NOT NULL UNIQUE
);

-- 4. جدول الأعوام الدراسية
CREATE TABLE IF NOT EXISTS academic_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  is_current BOOLEAN DEFAULT FALSE
);

-- 5. جدول أنواع المحتوى
CREATE TABLE IF NOT EXISTS content_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  icon TEXT
);

-- 6. جدول المواد الدراسية
CREATE TABLE IF NOT EXISTS subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  major_id UUID NOT NULL REFERENCES majors(id) ON DELETE CASCADE,
  level_id UUID NOT NULL REFERENCES levels(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(major_id, level_id, name)
);

-- 7. جدول الملفات الشخصية للمستخدمين
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  university_id UUID REFERENCES universities(id),
  major_id UUID REFERENCES majors(id),
  level_id UUID REFERENCES levels(id),
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. جدول الملفات الدراسية
CREATE TABLE IF NOT EXISTS study_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  file_type TEXT NOT NULL,
  content_type_id UUID NOT NULL REFERENCES content_types(id),
  subject_id UUID NOT NULL REFERENCES subjects(id),
  academic_year_id UUID NOT NULL REFERENCES academic_years(id),
  uploader_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  views_count INT DEFAULT 0,
  downloads_count INT DEFAULT 0,
  is_approved BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. جدول الملفات المحفوظة
CREATE TABLE IF NOT EXISTS saved_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_id UUID NOT NULL REFERENCES study_files(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, file_id)
);

-- 10. جدول تقييمات الملفات
CREATE TABLE IF NOT EXISTS file_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_id UUID NOT NULL REFERENCES study_files(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, file_id)
);

-- 11. جدول التعليقات
CREATE TABLE IF NOT EXISTS comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_id UUID NOT NULL REFERENCES study_files(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. جدول البلاغات
CREATE TABLE IF NOT EXISTS file_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_id UUID NOT NULL REFERENCES study_files(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'resolved', 'dismissed')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- إنشاء الفهارس للأداء
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_majors_university ON majors(university_id);
CREATE INDEX IF NOT EXISTS idx_subjects_major ON subjects(major_id);
CREATE INDEX IF NOT EXISTS idx_subjects_level ON subjects(level_id);
CREATE INDEX IF NOT EXISTS idx_profiles_university ON profiles(university_id);
CREATE INDEX IF NOT EXISTS idx_profiles_major ON profiles(major_id);
CREATE INDEX IF NOT EXISTS idx_study_files_subject ON study_files(subject_id);
CREATE INDEX IF NOT EXISTS idx_study_files_uploader ON study_files(uploader_id);
CREATE INDEX IF NOT EXISTS idx_study_files_content_type ON study_files(content_type_id);
CREATE INDEX IF NOT EXISTS idx_saved_files_user ON saved_files(user_id);
CREATE INDEX IF NOT EXISTS idx_file_ratings_file ON file_ratings(file_id);
CREATE INDEX IF NOT EXISTS idx_comments_file ON comments(file_id);
CREATE INDEX IF NOT EXISTS idx_file_reports_status ON file_reports(status);

-- =====================================================
-- تفعيل Row Level Security
-- =====================================================

ALTER TABLE universities ENABLE ROW LEVEL SECURITY;
ALTER TABLE majors ENABLE ROW LEVEL SECURITY;
ALTER TABLE levels ENABLE ROW LEVEL SECURITY;
ALTER TABLE academic_years ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_reports ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- سياسات الأمان (RLS Policies)
-- =====================================================

-- Universities: قراءة للجميع
CREATE POLICY "universities_select_all" ON universities FOR SELECT USING (true);
CREATE POLICY "universities_admin_all" ON universities FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Majors: قراءة للجميع
CREATE POLICY "majors_select_all" ON majors FOR SELECT USING (true);
CREATE POLICY "majors_admin_all" ON majors FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Levels: قراءة للجميع
CREATE POLICY "levels_select_all" ON levels FOR SELECT USING (true);
CREATE POLICY "levels_admin_all" ON levels FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Academic Years: قراءة للجميع
CREATE POLICY "academic_years_select_all" ON academic_years FOR SELECT USING (true);
CREATE POLICY "academic_years_admin_all" ON academic_years FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Content Types: قراءة للجميع
CREATE POLICY "content_types_select_all" ON content_types FOR SELECT USING (true);
CREATE POLICY "content_types_admin_all" ON content_types FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Subjects: قراءة للجميع
CREATE POLICY "subjects_select_all" ON subjects FOR SELECT USING (true);
CREATE POLICY "subjects_admin_all" ON subjects FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Profiles: المستخدم يرى ويعدل ملفه الشخصي فقط
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_select_public" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_admin_all" ON profiles FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Study Files: قراءة ملفات نفس الجامعة والتخصص
CREATE POLICY "study_files_select_same_university_major" ON study_files FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM profiles p
    JOIN subjects s ON s.id = study_files.subject_id
    JOIN majors m ON m.id = s.major_id
    WHERE p.id = auth.uid()
    AND p.university_id = m.university_id
    AND p.major_id = m.id
  )
  OR
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Study Files: رفع في نفس الجامعة والتخصص والمستوى أو أقل
CREATE POLICY "study_files_insert_own" ON study_files FOR INSERT WITH CHECK (
  auth.uid() = uploader_id
  AND EXISTS (
    SELECT 1 FROM profiles p
    JOIN subjects s ON s.id = study_files.subject_id
    JOIN majors m ON m.id = s.major_id
    JOIN levels l ON l.id = s.level_id
    JOIN levels user_level ON user_level.id = p.level_id
    WHERE p.id = auth.uid()
    AND p.university_id = m.university_id
    AND p.major_id = m.id
    AND l.order_num <= user_level.order_num
  )
);

-- Study Files: تعديل وحذف الملفات الخاصة
CREATE POLICY "study_files_update_own" ON study_files FOR UPDATE USING (auth.uid() = uploader_id);
CREATE POLICY "study_files_delete_own" ON study_files FOR DELETE USING (auth.uid() = uploader_id);
CREATE POLICY "study_files_admin_all" ON study_files FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Saved Files: المستخدم يدير ملفاته المحفوظة
CREATE POLICY "saved_files_select_own" ON saved_files FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "saved_files_insert_own" ON saved_files FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "saved_files_delete_own" ON saved_files FOR DELETE USING (auth.uid() = user_id);

-- File Ratings: المستخدم يدير تقييماته
CREATE POLICY "file_ratings_select_all" ON file_ratings FOR SELECT USING (true);
CREATE POLICY "file_ratings_insert_own" ON file_ratings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "file_ratings_update_own" ON file_ratings FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "file_ratings_delete_own" ON file_ratings FOR DELETE USING (auth.uid() = user_id);

-- Comments: الجميع يقرأ، المستخدم يدير تعليقاته
CREATE POLICY "comments_select_all" ON comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_own" ON comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "comments_update_own" ON comments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "comments_delete_own" ON comments FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "comments_admin_delete" ON comments FOR DELETE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- File Reports: المستخدم ينشئ بلاغاته، المشرف يدير الكل
CREATE POLICY "file_reports_insert_own" ON file_reports FOR INSERT WITH CHECK (auth.uid() = reporter_id);
CREATE POLICY "file_reports_select_own" ON file_reports FOR SELECT USING (auth.uid() = reporter_id);
CREATE POLICY "file_reports_admin_all" ON file_reports FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- =====================================================
-- Trigger لإنشاء profile تلقائياً عند التسجيل
-- =====================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', NULL),
    COALESCE(NEW.raw_user_meta_data ->> 'avatar_url', NEW.raw_user_meta_data ->> 'picture', NULL)
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- =====================================================
-- Trigger لتحديث updated_at
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
