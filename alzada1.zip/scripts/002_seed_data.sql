-- =====================================================
-- منصة الزاد - البيانات الأولية
-- =====================================================

-- المستويات الدراسية
INSERT INTO levels (name, order_num) VALUES
  ('السنة الأولى', 1),
  ('السنة الثانية', 2),
  ('السنة الثالثة', 3),
  ('السنة الرابعة', 4)
ON CONFLICT (name) DO NOTHING;

-- أنواع المحتوى
INSERT INTO content_types (name, icon) VALUES
  ('ملزمة', 'FileText'),
  ('كتاب', 'BookOpen'),
  ('ملخص', 'FileStack'),
  ('نموذج اختبار', 'ClipboardList')
ON CONFLICT (name) DO NOTHING;

-- الأعوام الدراسية
INSERT INTO academic_years (name, is_current) VALUES
  ('2022-2023', false),
  ('2023-2024', false),
  ('2024-2025', true),
  ('2025-2026', false)
ON CONFLICT (name) DO NOTHING;

-- الجامعات اليمنية
INSERT INTO universities (name, description) VALUES
  ('جامعة صنعاء', 'أقدم وأكبر جامعة في اليمن، تأسست عام 1970'),
  ('جامعة عدن', 'ثاني أقدم جامعة في اليمن، تأسست عام 1975'),
  ('جامعة تعز', 'جامعة حكومية في محافظة تعز'),
  ('جامعة الحديدة', 'جامعة حكومية في محافظة الحديدة'),
  ('جامعة إب', 'جامعة حكومية في محافظة إب')
ON CONFLICT (name) DO NOTHING;

-- التخصصات (سيتم إضافتها لكل جامعة)
DO $$
DECLARE
  uni RECORD;
  major_names TEXT[] := ARRAY[
    'علوم الحاسوب',
    'نظم المعلومات',
    'هندسة البرمجيات',
    'الطب البشري',
    'الصيدلة',
    'طب الأسنان',
    'الهندسة المدنية',
    'الهندسة الكهربائية',
    'الهندسة المعمارية',
    'المحاسبة',
    'إدارة الأعمال',
    'الاقتصاد',
    'اللغة العربية',
    'اللغة الإنجليزية',
    'التاريخ',
    'الشريعة والقانون'
  ];
  major_name TEXT;
BEGIN
  FOR uni IN SELECT id FROM universities LOOP
    FOREACH major_name IN ARRAY major_names LOOP
      INSERT INTO majors (university_id, name)
      VALUES (uni.id, major_name)
      ON CONFLICT (university_id, name) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;

-- المواد الدراسية (سيتم إضافتها لتخصص علوم الحاسوب كمثال)
DO $$
DECLARE
  major_rec RECORD;
  level_rec RECORD;
  subjects_l1 TEXT[] := ARRAY['مقدمة في البرمجة', 'أساسيات الحاسوب', 'الرياضيات المتقطعة', 'اللغة الإنجليزية 1'];
  subjects_l2 TEXT[] := ARRAY['هياكل البيانات', 'قواعد البيانات', 'نظم التشغيل', 'البرمجة الشيئية'];
  subjects_l3 TEXT[] := ARRAY['تحليل وتصميم النظم', 'الذكاء الاصطناعي', 'شبكات الحاسوب', 'هندسة البرمجيات'];
  subjects_l4 TEXT[] := ARRAY['مشروع التخرج', 'أمن المعلومات', 'الحوسبة السحابية', 'تطبيقات الويب'];
  subject_name TEXT;
BEGIN
  FOR major_rec IN 
    SELECT m.id as major_id 
    FROM majors m 
    WHERE m.name = 'علوم الحاسوب'
  LOOP
    -- المستوى الأول
    SELECT id INTO level_rec FROM levels WHERE order_num = 1;
    FOREACH subject_name IN ARRAY subjects_l1 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    -- المستوى الثاني
    SELECT id INTO level_rec FROM levels WHERE order_num = 2;
    FOREACH subject_name IN ARRAY subjects_l2 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    -- المستوى الثالث
    SELECT id INTO level_rec FROM levels WHERE order_num = 3;
    FOREACH subject_name IN ARRAY subjects_l3 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    -- المستوى الرابع
    SELECT id INTO level_rec FROM levels WHERE order_num = 4;
    FOREACH subject_name IN ARRAY subjects_l4 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;

-- مواد لتخصص الطب البشري
DO $$
DECLARE
  major_rec RECORD;
  level_rec RECORD;
  subjects_l1 TEXT[] := ARRAY['التشريح 1', 'الكيمياء الحيوية', 'علم الأنسجة', 'الفيزياء الطبية'];
  subjects_l2 TEXT[] := ARRAY['التشريح 2', 'علم وظائف الأعضاء', 'علم الأدوية 1', 'علم الأحياء الدقيقة'];
  subjects_l3 TEXT[] := ARRAY['الباطنة', 'الجراحة', 'طب الأطفال', 'التوليد وأمراض النساء'];
  subjects_l4 TEXT[] := ARRAY['الطب السريري', 'طب الطوارئ', 'الطب الشرعي', 'أخلاقيات الطب'];
  subject_name TEXT;
BEGIN
  FOR major_rec IN 
    SELECT m.id as major_id 
    FROM majors m 
    WHERE m.name = 'الطب البشري'
  LOOP
    SELECT id INTO level_rec FROM levels WHERE order_num = 1;
    FOREACH subject_name IN ARRAY subjects_l1 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    SELECT id INTO level_rec FROM levels WHERE order_num = 2;
    FOREACH subject_name IN ARRAY subjects_l2 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    SELECT id INTO level_rec FROM levels WHERE order_num = 3;
    FOREACH subject_name IN ARRAY subjects_l3 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
    
    SELECT id INTO level_rec FROM levels WHERE order_num = 4;
    FOREACH subject_name IN ARRAY subjects_l4 LOOP
      INSERT INTO subjects (major_id, level_id, name)
      VALUES (major_rec.major_id, level_rec.id, subject_name)
      ON CONFLICT (major_id, level_id, name) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;
